const About = () => {
    return ( 
        <div className="about">
            <h2>about us</h2>
        </div>
     );
}
 
export default About;