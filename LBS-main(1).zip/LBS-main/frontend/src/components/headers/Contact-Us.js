const Contact = () => {
    return (
        <div className="contact">
            <h2>Contact us</h2>
        </div>
     );
}
 
export default Contact;